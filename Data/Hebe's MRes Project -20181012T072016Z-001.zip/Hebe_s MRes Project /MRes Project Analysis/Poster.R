#For Poster
# hebe 

library(tidyverse)
library(splines)
library(lme4)
library(car)
library(MESS)

# data
SGR_Ind <- read_csv("GrowthInd_HC0.csv")

SGR_Ind <- SGR_Ind %>% filter(Experiment == "Chronic" )
SGR_Ind
# Model SGR
model_SGR <- lmer(Growth2 ~ bs(Temperature)*Treatment+
                    ( Treatment + bs(Temperature)|Clone), data = SGR_Ind)


# Anova from car and the F-test via kenward-rogers (everyone expects this)
Anova(model_SGR, test.statistic = "F")

summary(model_SGR)


# fit model with simplest random effect justified by design
# (1|Clone)
model_SGR_Simple <- lmer(Growth2 ~ bs(Temperature)*Treatment+
                           (1|Clone), data = SGR_Ind)

# compare complex to simple
anova(model_SGR, model_SGR_Simple)

# observed vs. predicted
plot(predict(model_SGR, type = 'response') ~ na.omit(SGR_Ind$Growth2))
abline(0,1)

# plot SGR
newX <- expand.grid(
  Temperature = seq(13,28,length = 50),
  Treatment = unique(SGR_Ind$Treatment),
  Clone = unique(SGR_Ind$Clone)
)

# new Y's - one for average (fixed) and one for each clone (re.form = ~....)
fixed_pred <- predict(model_SGR, newdata = newX, re.form = NA)
clone_pred <- predict(model_SGR, newdata = newX, re.form = ~(Treatment+bs(Temperature)|Clone))

# housekeeping
pd <- data.frame(newX, fixed_pred, clone_pred)

Results_PlotSGR <- ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = Temperature, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  labs(y = "Predicted Somatic Growth Rate (mm/day)", x = "Temperature (°C)", tag = "a") +
  theme_bw() +
  facet_grid(~ Treatment) +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

Results_PlotSGR
# AUCs
AUC <- pd %>% group_by(Clone, Treatment) %>% 
  summarise(AUC = auc(x = Temperature, y = clone_pred))

AUCsum <- AUC %>% group_by(Treatment) %>% 
  summarise(meanAUC = mean(AUC),
            seAUC = sd(AUC)/sqrt(sum(!is.na(AUC))))

# predation increases marginally the AUC.
AUC_PlotSGR <- ggplot(AUCsum, aes(x = Treatment, y = meanAUC, ymin = meanAUC - seAUC, ymax = meanAUC + seAUC))+
  geom_point(position = position_dodge(0.25), size = 4, colour = "gold")+
  geom_line(position = position_dodge(0.25))+
  geom_errorbar(width = 0.1, position = position_dodge(0.25), colour = "gold")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10)) +
  labs(y = "SGR Aera Under The Curve", tag = "b")

AUC_PlotSGR
aucMod <- lm(AUC ~ Treatment, data = AUC)
Anova(aucMod)


# More about SHAPE of the Curves

# first get the rows of the predictions
# where the prediction is highest (the peak)
SGR_Max_Topt <- Opt <- pd %>% 
  filter(fixed_pred == max(fixed_pred))

# now get the rows at 13C (the min temp)
SGR_TMin <- pd %>% 
  group_by(Treatment) %>% 
  filter(Temperature == 13)

# and the rows at 28C (the max temp)
SGR_TMax <- pd %>% 
  group_by(Treatment) %>% 
  filter(Temperature == 28)

# put them together and create the Metric column
SGR_out <- bind_rows(SGR_Max_Topt, SGR_TMin, SGR_TMax) %>% ungroup() %>% 
  mutate(., Metric = rep(c("Opt", "Min", "Max"), each = 20))

# SHOW how the Shapes change via alterations in values of Ro at Max Temp, Min Temp and Opt Temp.

# first show how values of Ro change among the treatments at Max, Min and Optimal Temp.
SGR_TPC1 <- ggplot(SGR_out, aes(x = Treatment, y = fixed_pred, group = Temperature, colour = Temperature))+
  geom_point(size = 4, colour = "gold") + geom_line(colour = "gold") +
  ylab(expression(atop("Predicted Somatic Growth", paste("Rate (mm/day)"))))+
  labs(tag = "c") +
  facet_grid( ~ Metric)+
  theme_bw(base_size = 15) + 
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

SGR_TPC1
# second show how the optimal temperature (where the peak happens in temperature space)
# changes among the treatments...
# NOTE how the optimal temperature for Ro is at the min Temp for both predator and no predator under
# acute, but that it's higher under acclim, and that predation lowers the temperature at which max Ro 
# occurs!

SGR_TPC2 <- ggplot(filter(SGR_out, Metric == "Opt"), 
                   aes(x = Treatment, y = Temperature))+
  geom_point(size = 3, colour = "gold")+geom_line(colour = "gold")+
  ylab(expression(atop("Temperature at which Maximum", paste("SGR Occurs (Topt) (°C)"))))+ ylim(22, 25) +
  labs(tag = "d")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

SGR_TPC2 

gridExtra::grid.arrange(SGR_TPC1, SGR_TPC2, ncol = 2)

# ALL RESULTS 1 PANE
gridExtra::grid.arrange(Results_PlotSGR, AUC_PlotSGR, SGR_TPC1, SGR_TPC2, ncol = 2, nrow = 3,
                        layout_matrix = rbind(c(1,2), c(1,3), c(1,4)))
