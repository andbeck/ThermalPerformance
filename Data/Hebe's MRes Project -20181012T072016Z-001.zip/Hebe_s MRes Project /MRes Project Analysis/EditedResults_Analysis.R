# Hebe All Data
rm(list=ls())
library(tidyverse)

# all data
#allDat <- read_csv("AllResults_22_07_18.csv")
allDat <- read_csv(file.choose())

allDat2 <- 
  allDat %>%
  mutate(Experiment = ifelse(Experiment == "Aclim", "Acclim", Experiment)) %>% 
  mutate(Stage = ifelse(Stage == "Mature", "mt", Stage)) %>% 
  mutate(Clone = ifelse(Clone == "LD34"| Clone == "LD35", "LD33", Clone)) %>%
  filter(Clone != "D10_74")


###### Juvenile Growth Rate ###### ------------------------------------------------------------------------------------
GDat <- filter(allDat2, Age == "1" | Stage == "mt")
GDat

GGdat <-filter(GDat, Stage == "mt")
write.csv(GGdat, "GGDat.csv")

initialDat <- GDat %>% mutate(ISize = (Age == "1" ))
initialDat

growth <- initialDat %>% group_by(ID) %>% arrange(Age) %>% 
  mutate(Growth = log(last(Body)/ first(Body))/ last(Age))

GrowthRate <- filter(growth, ISize == "FALSE")
GrowthRate

# Mean growth rate
GrowthDatMean <- GrowthRate %>%
  group_by(Clone, Temperature, Treatment, Experiment) %>% arrange(Treatment) %>%
  summarise(meanGrowth = mean(Growth, na.rm = TRUE),
            seGrowth = sd(Growth, na.rm = TRUE)/
              sqrt(sum(!is.na(Growth))))

GrowthDatMean
# clones seperated
ggplot(GrowthDatMean, aes(x= Temperature, y= meanGrowth, group = Treatment, colour = Treatment)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = meanGrowth - seGrowth, ymax = meanGrowth + seGrowth), width = .1) +
  facet_grid(Experiment ~ Clone) +
  ylab("Average growth rate (mm per day)")

### All clones together
ggplot(GrowthDatMean, aes(x= Temperature, y= meanGrowth, group = Clone, colour = Clone)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = meanGrowth - seGrowth, ymax = meanGrowth + seGrowth), width = .1) +
  facet_grid(Experiment ~ Treatment) +
  ylab("Average juvenile growth rate (mm per day)")

### juvinile growth from day 2 ### --------
GDat2 <- filter(allDat2, Age == "2" | Stage == "mt")
GDat2

write.csv(GDat2, "GDat2.csv")

initialDat2 <- GDat2 %>% mutate(ISize = (Age == "2" ))
initialDat2

growth2 <- initialDat2 %>% group_by(ID) %>% arrange(Age) %>% 
  mutate(Growth2 = log(last(Body)/ first(Body))/ last(Age))

GrowthRate2 <- filter(growth2, ISize == "FALSE")
GrowthRate2

# Mean growth rate
GrowthDatMean2 <- GrowthRate2 %>%
  group_by(Clone, Temperature, Treatment, Experiment) %>% arrange(Treatment) %>%
  summarise(meanGrowth2 = mean(Growth, na.rm = TRUE),
            seGrowth2 = sd(Growth, na.rm = TRUE)/
              sqrt(sum(!is.na(Growth))))

GrowthDatMean2
# clones seperated
ggplot(GrowthDatMean2, aes(x= Temperature, y= meanGrowth2, group = Treatment, colour = Treatment)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = meanGrowth2 - seGrowth2, ymax = meanGrowth2 + seGrowth2), width = .1) +
  facet_grid(Experiment ~ Clone) +
  ylab("Average growth rate (mm per day)")

### All clones together
ggplot(GrowthDatMean2, aes(x= Temperature, y= meanGrowth2, group = Clone, colour = Clone)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = meanGrowth2 - seGrowth2, ymax = meanGrowth2 + seGrowth2), width = .1) +
  facet_grid(Experiment ~ Treatment) +
  ylab("Average juvenile growth rate (mm per day)")


### plots of growth1 and growth2
GaM_clone <- ggplot(GrowthDatMean, aes(x = Temperature, y = meanGrowth, colour = Treatment))+
  geom_point()+
  geom_smooth(method = lm, formula = y ~ poly(x, 2), se = FALSE)+
  facet_wrap(~Experiment)

GaM_clone2 <- ggplot(GrowthDatMean2, aes(x = Temperature, y = meanGrowth2, colour = Treatment))+
  geom_point()+
  geom_smooth(method = lm, formula = y ~ poly(x, 2), se = FALSE)+
  facet_wrap(~Experiment)

gridExtra::grid.arrange(GaM_clone, GaM_clone2)


### Plot2 
G1aM <- ggplot(GrowthRate, aes(x = Temperature, y = Growth, 
                          colour = Clone))+
  geom_point()+
  geom_smooth(method = lm, formula = y ~ poly(x,2), se = FALSE)+
  facet_grid(Treatment ~ Experiment + Clone)+
  theme_bw()
G1aM


G2aM <- ggplot(GrowthRate2, aes(x = Temperature, y = Growth2, 
                               colour = Clone))+
  geom_point()+
  geom_smooth(method = lm, formula = y ~ poly(x,2), se = FALSE)+
  facet_grid(Treatment ~ Experiment + Clone)+
  theme_bw()
G2aM


##### growth ignoring initial size
GDat0 <- filter(allDat2,  Stage == "mt")
GDat0

#write.csv(GDat0, "GDat0.csv")

growth0 <- GDat0 %>% group_by(ID) %>% 
  mutate(Growth0 = log(Body)/Age)

growth0

write.csv(growth0, "growth0.csv")





#### Maximum Induction #### --------------------------------------------------------------------
# full induction
FullInd <- allDat2 %>% mutate(Spikes = ifelse(Spikes == "1", "10", Spikes)) %>%
  mutate(Spikes = ifelse(Spikes == "2", "20", Spikes)) %>%
  mutate(Spikes = ifelse(Spikes == "3", "30", Spikes)) %>%
  mutate(Spikes = ifelse(Spikes == "4", "40", Spikes)) %>%
  mutate(Spikes = ifelse(Spikes == "5", "50", Spikes)) %>%
  mutate(Spikes = ifelse(Spikes == "6", "60", Spikes))

FullInd <- transform(FullInd, Spikes = as.numeric(Spikes),
                     Pedestal = as.numeric(Pedestal))

FullInd2 <- FullInd %>% mutate(totalInd = Spikes + Pedestal)
FullInd2

# Max Induction
MaxInd <- FullInd2 %>% 
  group_by(ID, Treatment, Temperature, Clone, Experiment) %>%
  summarise(maxInduction = max(totalInd))
MaxInd

# average Max Induction
IndMean <- MaxInd %>%
  group_by(Clone, Treatment, Temperature, Experiment) %>% 
  summarise(meanMaxInd = mean(maxInduction, na.rm = TRUE),
            seMaxInd = sd(maxInduction, na.rm = TRUE)/
              sqrt(sum(!is.na(maxInduction))))
IndMean

ggplot(IndMean, aes(x= Temperature, y= meanMaxInd, group = Clone, colour = Clone)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = meanMaxInd - seMaxInd, ymax = meanMaxInd + seMaxInd), width = .1) +
  facet_grid(Experiment ~ Treatment) +
  ylab("Average maximum induction")




#### Population Growth Rate (Ro) #### -------------------------------------------------------

# Get the population growth data
PopGDat <- read_csv(file.choose())
PopGDat

RoDat <- PopGDat %>% group_by(Stage, Treatment, Temperature, Experiment, Clone) %>%
  mutate(Ind.Ro = Survival * Mean.Rep) 
RoDat

RoDatB3 <- RoDat %>% filter(Stage %in% c("B1", "B2", "B3")) 
RoDatB3

RoDatB1 <- RoDat %>% filter(Stage == "B1")
RoDatB1

# caculate the sum of population growth over all the births
SumRoDatB3 <- aggregate(Ind.Ro ~ Clone + Temperature + Treatment + Experiment, data = RoDatB3, sum)
SumRoDatB2 <- aggregate(Ind.Ro ~ Clone + Temperature + Treatment + Experiment, data = RoDatB2B1, sum)
SumRoDatB1 <- aggregate(Ind.Ro ~ Clone + Temperature + Treatment + Experiment, data = RoDatB1, sum)
SumRoDatB3
SumRoDatB2
SumRoDatB1

write.csv(SumRoDatB3, "RoB3.csv")

#Plot
ggplot(SumRoDatB2, aes(x = Temperature, y = Ind.Ro,
                     colour = Clone))+
  geom_point()+
  geom_smooth(method = lm, formula = y ~ poly(x,2), se = FALSE)+
  facet_grid(Treatment~Experiment)+
  theme_bw()


#### Merge Data sets ### --------------------------------
RoDataFinal <- read_csv(file.choose())

MergeData <- merge(RoDataFinal, GrowthDatMean, by = c("Clone", "Temperature", "Experiment", "Treatment"))
MergeData

MergedData <- merge(MergeData, IndMean, by = c("Clone", "Temperature", "Experiment", "Treatment"))
MergedData

write.csv(MergedData, "MergedData.csv")

write.csv(GrowthInd, "GrowthInd.csv")

growthInd2 <- read_csv(file.choose())
GrowthInd <- full_join(GrowthRate, MaxInd, by = c("ID", "Clone", "Temperature", "Treatment", "Experiment"))
GrowthInd
write.csv(GrowthInd0, "GrowthInd0.csv")

growthInd3 <- read_csv(file.choose())
GrowthInd0 <- full_join(growth0, growthInd3, by = c("ID", "Clone", "Temperature", "Treatment", "Experiment"))
GrowthInd0
