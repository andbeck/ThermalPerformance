# Presentation figures - no acute

library(tidyverse)
library(splines)
library(lme4)
library(car)
library(MESS)

# data
Ro <- read_csv("RoData_HC.csv")
SGR_Ind <- read_csv("GrowthInd_HC0.csv")

RoAcclim <- filter(Ro, Experiment == "Chronic")
RoAcclim

SGR_Ind
SGR_INDAcclim <- filter(SGR_Ind, Experiment == "Chronic")
SGR_INDAcclim


mod_Ro2 <- lm(Ro.B2 ~ bs(Temperature) * Treatment,
              data = RoAcclim)

newX <- expand.grid(
  Temperature = seq(13,28,length = 100),
  Treatment = unique(RoAcclim$Treatment))
fixed_pred <- predict(mod_Ro2, newdata = newX)
pd <- data.frame(newX, fixed_pred)

Results_Plot <- ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 1.75)+
  geom_jitter(data = RoAcclim, aes(x = Temperature, y = Ro.B2, colour = Clone), alpha = 0.6,
              height = 0, width = 0.25, size = 1.75)+
  xlim(13,28) + ylim(0, 30) +
  facet_grid( ~ Treatment)+
  labs(y = "Population Growth Rate (Ro)", x = "Temperature (°C)")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.text = element_text(size = 12), strip.text = element_text(size = 14, face = "bold"))
Results_Plot

AUC <- pd %>% group_by(Treatment) %>% 
  summarise(AUC = auc(x = Temperature, y = fixed_pred, type = "spline"))

AUC_Plot <- ggplot(AUC, aes(x = Treatment, y = AUC))+
  geom_point(size = 3, colour = "blue")+
  geom_line()+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10)) +
  labs(y = "Ro Aera Under The Curve")

AUC_Plot


######### SGR #########
# Model SGR
model_SGR <- lmer(Growth2 ~ bs(Temperature)*Treatment+
                    (Treatment + bs(Temperature)|Clone), data = SGR_INDAcclim)
Anova(model_SGR,  test.statistic = "F")
newX <- expand.grid(
  Temperature = seq(13,28,length = 50),
  Treatment = unique(SGR_INDAcclim$Treatment),
  Clone = unique(SGR_INDAcclim$Clone))

fixed_pred <- predict(model_SGR, newdata = newX, re.form = NA)
clone_pred <- predict(model_SGR, newdata = newX, re.form = ~(Treatment+bs(Temperature)|Clone))

pd <- data.frame(newX, fixed_pred, clone_pred)


Results_PlotSGR <- ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = Temperature, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  labs(y = "Predicted Somatic Growth Rate (mm/day)", x = "Temperature (°C)") +
  theme_bw() +
  facet_grid( ~ Treatment) +
  theme(axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.text = element_text(size = 12), strip.text = element_text(size = 14, face = "bold"))
Results_PlotSGR

# AUCs
AUC <- pd %>% group_by(Clone, Treatment) %>% 
  summarise(AUC = auc(x = Temperature, y = clone_pred))

AUCsum <- AUC %>% group_by(Treatment) %>% 
  summarise(meanAUC = mean(AUC),
            seAUC = sd(AUC)/sqrt(sum(!is.na(AUC))))
AUC_PlotSGR <- ggplot(AUCsum, aes(x = Treatment, y = meanAUC, ymin = meanAUC - seAUC, ymax = meanAUC + seAUC
                                  ))+
  geom_point(position = position_dodge(0.25), size = 5, colour = "orange")+
  geom_line(position = position_dodge(0.25))+
  geom_errorbar(width = 0.1, position = position_dodge(0.25), colour = "orange")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.text = element_text(size = 16)) +
  labs(y = "SGR Aera Under The Curve")
AUC_PlotSGR



# Model Ind
model_Ind <- lmer(maxInduction ~ Temperature*Treatment+
                    (Treatment+Temperature|Clone), data = SGR_Ind)
Anova(model_Ind, test.statistic = "F")
newX <- expand.grid(
  Temperature = seq(13,28,1),
  Treatment = unique(SGR_INDAcclim$Treatment),
  Clone = unique(SGR_INDAcclim$Clone))

fixed_pred <- predict(model_Ind, newdata = newX, re.form = NA)
clone_pred <- predict(model_Ind, newdata = newX, re.form = ~(Treatment+Temperature|Clone))

pd <- data.frame(newX, fixed_pred, clone_pred)

ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = Temperature, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  facet_grid(~ Treatment)+
  labs(y = "Predicted Maximum Induction Score", x = "Temperature (°C)")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.text = element_text(size = 12), strip.text = element_text(size = 12, face = "bold"))

pred_only <- filter(SGR_INDAcclim, Treatment == "Predator")
modTrad <- lmer(Growth2 ~ maxInduction +
                  (maxInduction|Clone), data = SGR_INDAcclim)
newX <- expand.grid(
  maxInduction = seq(0,100, 1),
  Clone = unique(SGR_INDAcclim$Clone)
)

fixed_pred <- predict(modTrad, newdata = newX, re.form = NA)
clone_pred <- predict(modTrad, newdata = newX, re.form = ~(maxInduction|Clone))

pd <- data.frame(newX, fixed_pred, clone_pred)

ggplot(pd, aes(x = maxInduction, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = maxInduction, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  labs(y = "Predicted Somatic Growth Rate (mm/ day)", x = "Maximum Induction Score")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.text = element_text(size = 12), strip.text = element_text(size = 12, face = "bold"))

