library(tidyverse)
library(splines)
library(lme4)
library(car)
library(MESS)

hd <- read_csv("PopulationGrowth.csv")
hd

hdB1 <- hd %>% filter(Stage == "B1")
hdB1

hdB1 %>% filter(Survival == "0.83")

hdB1 %>% filter(Survival == "0")

hdB0 <- hd %>% filter(Stage == "B0")
hdB0

hdB0 %>% filter(Survival == "0.67") 
