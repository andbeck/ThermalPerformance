# hebe 

library(tidyverse)
library(splines)
library(lme4)
library(car)
library(MESS)

# data
Ro <- read_csv("RoData_HC.csv")
SGR_Ind <- read_csv("GrowthInd_HC0.csv")

## Pop Growth Rate - Ro -----------------------------------------------------
# graphs to start
#Ro_3 <- ggplot(Ro, aes(x = Temperature, y = Ro.B3, colour = Treatment,
#                       group = Treatment))+
# geom_point() + ylim(0,50) +
#geom_smooth(method = "lm", se = FALSE, formula = y ~ poly(x,2))+
#  facet_wrap( ~ Experiment)+
#  theme_bw()


#Ro_2 <- ggplot(Ro, aes(x = Temperature, y = Ro.B2, colour = Treatment,
#                       group = Treatment))+
#  geom_point() + ylim(0,50) +
#  geom_smooth(method = "lm", se = FALSE, formula = y ~ poly(x,2))+
#  facet_wrap( ~ Experiment)+
#  theme_bw()


#Ro_1 <- ggplot(Ro, aes(x = Temperature, y = Ro.B1, colour = Treatment,
#                       group = Treatment))+
#  geom_point() + ylim(0,50) +
#  geom_smooth(method = "lm", se = FALSE, formula = y ~ poly(x,2))+
#  facet_wrap( ~ Experiment)+
#  theme_bw()


#gridExtra::grid.arrange(Ro_1, Ro_2, Ro_3, ncol = 3)


# model Ro ------------------------------------------------------------

# CHOOSE ONE
# model with spline
mod_Ro2 <- lm(Ro.B2 ~ bs(Temperature) * Treatment * Experiment,
              data = Ro)

# model via polynomial
# mod_Ro2 <- lm(Ro.B2 ~ poly(Temperature,2) * Treatment * Experiment,
#               data = Ro)

par(mfrow = c(2,2))
plot(mod_Ro2)

Anova(mod_Ro2)

# plot Ro Model --------------------

newX <- expand.grid(
  Temperature = seq(13,28,length = 100),
  Treatment = unique(Ro$Treatment),
  Experiment = unique(Ro$Experiment)
)

# predicted Ro
fixed_pred <- predict(mod_Ro2, newdata = newX)

# plot data Ro
pd <- data.frame(newX, fixed_pred)

# graph the curves Ro
Results_Plot <- ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 1.75)+
  geom_jitter(data = Ro, aes(x = Temperature, y = Ro.B2, colour = Clone), alpha = 0.6,
              height = 0, width = 0.25, size = 1.75)+
  xlim(13,28) + ylim(0, 50) +
  facet_grid(Experiment ~ Treatment)+
  labs(y = "Population Growth Rate (Ro)", x = "Temperature (°C)", tag = "a")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))


# AUC Ro
# calcuate area under the curves
AUC <- pd %>% group_by(Treatment, Experiment) %>% 
  summarise(AUC = auc(x = Temperature, y = fixed_pred, type = "spline"))

# plot the changes in AUC
AUC_Plot <- ggplot(AUC, aes(x = Treatment, y = AUC, colour = Experiment,
                group = Experiment))+
  geom_point(size = 3)+
  geom_line()+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10)) +
  labs(y = "Ro Aera Under The Curve", tag = "b")




# More about SHAPE of the Curves

# first get the rows of the predictions
# where the prediction is highest (the peak)
Ro_Max_Topt <- Opt <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(fixed_pred == max(fixed_pred))

# now get the rows at 13C (the min temp)
Ro_TMin <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(Temperature == 13)

# and the rows at 28C (the max temp)
Ro_TMax <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(Temperature == 28)

# put them together and create the Metric column
out <- bind_rows(Ro_Max_Topt, Ro_TMin, Ro_TMax) %>% ungroup() %>% 
  mutate(., Metric = rep(c("Opt", "Min", "Max"), each = 4))

# SHOW how the Shapes change via alterations in values of Ro at Max Temp, Min Temp and Opt Temp.

# first show how values of Ro change among the treatments at Max, Min and Optimal Temp.
TPC1 <- ggplot(out, aes(x = Treatment, y = fixed_pred, group = Experiment, colour = Experiment))+
  geom_point(size = 3)+geom_line()+
  ylab(expression(atop("Predicted Population", paste("Growth Rate (Ro)"))))+ ylim(5, 20) +
  labs(tag = "c")+
  facet_grid( ~ Metric)+
  theme_bw(base_size = 15)+
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10))
TPC1

# second show how the optimal temperature (where the peak happens in temperature space)
# changes among the treatments...
# NOTE how the optimal temperature for Ro is at the min Temp for both predator and no predator under
# acute, but that it's higher under acclim, and that predation lowers the temperature at which max Ro 
# occurs!

TPC2 <- ggplot(filter(out, Metric == "Opt"), 
               aes(x = Treatment, y = Temperature, colour = Experiment, group = Experiment))+
  geom_point(size = 3)+geom_line()+ 
  ylab(expression(atop("Temperature at which Maximum", paste("Ro Occurs (Topt) (°C)"))))+ ylim(12, 20)+
  labs(tag = "d") +
  theme_bw()+
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

TPC2
gridExtra::grid.arrange(TPC1, TPC2, ncol = 2)

# ALL RESULTS 1 PANE
gridExtra::grid.arrange(Results_Plot, AUC_Plot, TPC1, TPC2, ncol = 2,nrow = 3,
                        layout_matrix = rbind(c(1,2), c(1,3), c(1,4)))

## SGR ------------------------------------------

#SGR_finSize <- ggplot(SGR_Ind, aes(x = Temperature, y = Growth0, 
 #                                  colour = Clone))+
#  geom_point()+
#  geom_smooth(span = 1, se = FALSE)+
#  facet_grid(Treatment ~ Experiment+Clone)+
#  theme_bw()

#SGR_instar1 <- ggplot(SGR_Ind, aes(x = Temperature, y = Growth1, 
#                           colour = Clone))+
#  geom_point()+
#  geom_smooth(span = 1, se = FALSE)+
#  facet_grid(Treatment ~ Experiment+Clone)+
#  theme_bw()

#SGR_instar2 <- ggplot(SGR_Ind, aes(x = Temperature, y = Growth2, 
#                                   colour = Clone))+
#  geom_point()+
#  geom_smooth(span = 1, se = FALSE)+
#  facet_grid(Treatment ~ Experiment+Clone)+
#  theme_bw()

#gridExtra::grid.arrange(SGR_finSize, SGR_instar1, SGR_instar2)

# Model SGR
model_SGR <- lmer(Growth2 ~ bs(Temperature)*Treatment*Experiment+
                    (Experiment + Treatment + bs(Temperature)|Clone), data = SGR_Ind)


# Anova from car and the F-test via kenward-rogers (everyone expects this)
Anova(model_SGR, test.statistic = "F")

summary(model_SGR)


# fit model with simplest random effect justified by design
# (1|Clone)
model_SGR_Simple <- lmer(Growth2 ~ bs(Temperature)*Treatment*Experiment+
                         (1|Clone), data = SGR_Ind)

# compare complex to simple
anova(model_SGR, model_SGR_Simple)

# observed vs. predicted
plot(predict(model_SGR, type = 'response') ~ na.omit(SGR_Ind$Growth2))
abline(0,1)

# plot SGR
newX <- expand.grid(
  Temperature = seq(13,28,length = 50),
  Treatment = unique(SGR_Ind$Treatment),
  Experiment = unique(SGR_Ind$Experiment),
  Clone = unique(SGR_Ind$Clone)
)

# new Y's - one for average (fixed) and one for each clone (re.form = ~....)
fixed_pred <- predict(model_SGR, newdata = newX, re.form = NA)
clone_pred <- predict(model_SGR, newdata = newX, re.form = ~(Experiment+Treatment+bs(Temperature)|Clone))

# housekeeping
pd <- data.frame(newX, fixed_pred, clone_pred)

Results_PlotSGR <- ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = Temperature, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  labs(y = "Predicted Somatic Growth Rate (mm/day)", x = "Temperature (°C)", tag = "a") +
  theme_bw() +
  facet_grid(Experiment ~ Treatment) +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))


# AUCs
AUC <- pd %>% group_by(Clone, Treatment, Experiment) %>% 
  summarise(AUC = auc(x = Temperature, y = clone_pred))

AUCsum <- AUC %>% group_by(Treatment, Experiment) %>% 
  summarise(meanAUC = mean(AUC),
            seAUC = sd(AUC)/sqrt(sum(!is.na(AUC))))

# predation increases marginally the AUC.
AUC_PlotSGR <- ggplot(AUCsum, aes(x = Treatment, y = meanAUC, ymin = meanAUC - seAUC, ymax = meanAUC + seAUC,
                   colour = Experiment, group = Experiment))+
  geom_point(position = position_dodge(0.25), size = 3)+
  geom_line(position = position_dodge(0.25))+
  geom_errorbar(width = 0.1, position = position_dodge(0.25))+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10)) +
  labs(y = "SGR Aera Under The Curve", tag = "b")


aucMod <- lm(AUC ~ Treatment * Experiment, data = AUC)
Anova(aucMod)


# More about SHAPE of the Curves

# first get the rows of the predictions
# where the prediction is highest (the peak)
SGR_Max_Topt <- Opt <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(fixed_pred == max(fixed_pred))

# now get the rows at 13C (the min temp)
SGR_TMin <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(Temperature == 13)

# and the rows at 28C (the max temp)
SGR_TMax <- pd %>% 
  group_by(Treatment, Experiment) %>% 
  filter(Temperature == 28)

# put them together and create the Metric column
SGR_out <- bind_rows(SGR_Max_Topt, SGR_TMin, SGR_TMax) %>% ungroup() %>% 
  mutate(., Metric = rep(c("Opt", "Min", "Max"), each = 40))

# SHOW how the Shapes change via alterations in values of Ro at Max Temp, Min Temp and Opt Temp.

# first show how values of Ro change among the treatments at Max, Min and Optimal Temp.
SGR_TPC1 <- ggplot(SGR_out, aes(x = Treatment, y = fixed_pred, group = Experiment, colour = Experiment))+
  geom_point(size = 3)+geom_line()+
  ylab(expression(atop("Predicted Somatic Growth", paste("Rate (mm/day)"))))+
  labs(tag = "c") +
  facet_grid( ~ Metric)+
  theme_bw(base_size = 15) + 
  theme(axis.text.x = element_text(size = 10),
      axis.text.y = element_text(size = 10),
      axis.title.x = element_text(size = 12),
      axis.title.y = element_text(size = 12),
      legend.title = element_text(size = 12),
      legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

SGR_TPC1
# second show how the optimal temperature (where the peak happens in temperature space)
# changes among the treatments...
# NOTE how the optimal temperature for Ro is at the min Temp for both predator and no predator under
# acute, but that it's higher under acclim, and that predation lowers the temperature at which max Ro 
# occurs!

SGR_TPC2 <- ggplot(filter(SGR_out, Metric == "Opt"), 
               aes(x = Treatment, y = Temperature, colour = Experiment, group = Experiment))+
  geom_point(size = 3)+geom_line()+
  ylab(expression(atop("Temperature at which Maximum", paste("SGR Occurs (Topt) (°C)"))))+ ylim(22, 25) +
  labs(tag = "d")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

SGR_TPC2 

gridExtra::grid.arrange(SGR_TPC1, SGR_TPC2, ncol = 2)

# ALL RESULTS 1 PANE
gridExtra::grid.arrange(Results_PlotSGR, AUC_PlotSGR, SGR_TPC1, SGR_TPC2, ncol = 2, nrow = 3,
                        layout_matrix = rbind(c(1,2), c(1,3), c(1,4)))





# Induction ------------------------------------------

ggplot(SGR_Ind, aes(x = Temperature, y = maxInduction, 
                           colour = Clone))+
  geom_point()+
  geom_smooth(method = lm, se = FALSE)+
  facet_grid(Treatment ~ Experiment+Clone)+
  theme_bw()

# Model Ind
model_Ind <- lmer(maxInduction ~ Temperature*Treatment*Experiment+
                    (Experiment+Treatment+Temperature|Clone), data = SGR_Ind)

Anova(model_Ind, test.statistic = "F")

summary(model_Ind)

# test random effects
model_Ind_Simple <- lmer(maxInduction ~ Temperature*Treatment*Experiment+
                         (1|Clone), data = SGR_Ind)

anova(model_Ind, model_Ind_Simple)

# plot IND
newX <- expand.grid(
  Temperature = seq(13,28,1),
  Treatment = unique(SGR_Ind$Treatment),
  Experiment = unique(SGR_Ind$Experiment),
  Clone = unique(SGR_Ind$Clone)
)

fixed_pred <- predict(model_Ind, newdata = newX, re.form = NA)
clone_pred <- predict(model_Ind, newdata = newX, re.form = ~(Experiment+Treatment+Temperature|Clone))

pd <- data.frame(newX, fixed_pred, clone_pred)

ggplot(pd, aes(x = Temperature, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = Temperature, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  facet_grid(Experiment ~ Treatment)+
  labs(y = "Predicted Maximum Induction (Defence Morphology) Score", x = "Temperature (°C)")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))


# Trade-off -----------------------------------
pred_only <- filter(SGR_Ind, Treatment == "Predator")

# lots of variation in relationship
# including reversals
ggplot(pred_only, aes(x = maxInduction, y = Growth2, colour = Clone))+
  geom_point()+
  geom_smooth(method = "lm", se = FALSE)+
  facet_grid(Experiment ~ Clone)

# model
modTrad <- lmer(Growth2 ~ maxInduction*Experiment +
                  (Experiment+maxInduction|Clone), data = SGR_Ind)


# test random effects
modTrad_simple <- lmer(Growth2 ~ maxInduction*Experiment +
                  (1|Clone), data = SGR_Ind)

anova(modTrad, modTrad_simple)

# tests
Anova(modTrad, test.statistic = "F")
summary(modTrad)

# plot TradeOff Result
newX <- expand.grid(
  maxInduction = seq(0,100, 1),
  Experiment = unique(SGR_Ind$Experiment),
  Clone = unique(SGR_Ind$Clone)
)

fixed_pred <- predict(modTrad, newdata = newX, re.form = NA)
clone_pred <- predict(modTrad, newdata = newX, re.form = ~(Experiment+maxInduction|Clone))

pd <- data.frame(newX, fixed_pred, clone_pred)

ggplot(pd, aes(x = maxInduction, y = fixed_pred))+
  geom_line(size = 2)+
  geom_line(aes(x = maxInduction, y = clone_pred, colour = Clone), 
            size = 1, alpha = 0.6)+
  facet_grid(~Experiment)+
  labs(y = "Predicted Somatic Growth Rate (mm/ day)", x = "Maximum Induction (Defence Morphology) Score")+
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10), strip.text = element_text(size = 10, face = "bold"))

